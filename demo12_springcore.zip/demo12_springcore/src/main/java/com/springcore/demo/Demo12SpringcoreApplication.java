package com.springcore.demo;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.context.ApplicationContext;

@SpringBootApplication
public class Demo12SpringcoreApplication {

	public static void main(String[] args) {
		ApplicationContext context = SpringApplication.run(Demo12SpringcoreApplication.class, args);
		Payment payment = context.getBean(CreditCardPayment.class);
		payment.pay();
	}
}
