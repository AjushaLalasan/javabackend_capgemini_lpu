package com.notificationservice.demo;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class DemoNotificationserviceApplication {

	public static void main(String[] args) {
		SpringApplication.run(DemoNotificationserviceApplication.class, args);
	}

}
