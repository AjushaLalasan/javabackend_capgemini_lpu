package com.springmvc.demo.service;

import java.util.List;

import org.springframework.stereotype.Service;

import com.springmvc.demo.model.Product;
import com.springmvc.demo.repository.ProductDAO;

@Service
public class ProductService {

	private ProductDAO productDAO;

	public ProductService(ProductDAO productDAO) {
		this.productDAO = productDAO;
	}

	public List<Product> fetchProducts() {
		return productDAO.getAllProducts();
	}
}