package com.orderservice.demo.config;

import org.springframework.amqp.core.*;
import org.springframework.amqp.rabbit.connection.ConnectionFactory;
import org.springframework.amqp.rabbit.core.RabbitTemplate;
import org.springframework.amqp.support.converter.Jackson2JsonMessageConverter;
import org.springframework.amqp.support.converter.MessageConverter;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

@Configuration
public class RabbitMQConfig {

	// Messaging components
	public static final String EXCHANGE = "order-exchange";
	public static final String QUEUE = "notification-queue";
	public static final String ROUTING_KEY = "order.created";

	// Queue
	@Bean
	public Queue queue() {
		return new Queue(QUEUE);
	}

	// Exchange
	@Bean
	public TopicExchange exchange() {
		return new TopicExchange(EXCHANGE);
	}

	// Binding between Queue and Exchange
	@Bean
	public Binding binding() {
		return BindingBuilder.bind(queue()).to(exchange()).with(ROUTING_KEY);
	}

	// Message converter (Java object → JSON)
	@Bean
	public MessageConverter messageConverter() {
		return new Jackson2JsonMessageConverter();
	}

	// RabbitTemplate used by Producer to send messages
	@Bean
	public RabbitTemplate rabbitTemplate(ConnectionFactory connectionFactory) {

		RabbitTemplate rabbitTemplate = new RabbitTemplate(connectionFactory);
		rabbitTemplate.setMessageConverter(messageConverter());

		return rabbitTemplate;
	}
}