package com.hibernate.demo.demo9_hibernate_manytoone;


import jakarta.persistence.EntityManager;
import jakarta.persistence.EntityManagerFactory;
import jakarta.persistence.Persistence;
import jakarta.persistence.EntityTransaction;

public class App {

    public static void main(String[] args) {

        EntityManagerFactory emf =
                Persistence.createEntityManagerFactory("myPersistenceUnit");

        EntityManager em = emf.createEntityManager();

        EntityTransaction tx = em.getTransaction();

        tx.begin();

        // Create Department
        Department dept = new Department("Computer Science");
        em.persist(dept);

        // Create Students
        Student s1 = new Student("John", dept);
        Student s2 = new Student("Meena", dept);
        Student s3 = new Student("Arjun", dept);

        em.persist(s1);
        em.persist(s2);
        em.persist(s3);

        tx.commit();

        em.close();
        emf.close();

        System.out.println("Data inserted using EntityManager");
    }
}
