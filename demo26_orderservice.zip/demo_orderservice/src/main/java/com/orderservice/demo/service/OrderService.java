package com.orderservice.demo.service;

import org.springframework.stereotype.Service;

import com.orderservice.demo.dto.ProductResponseDTO;
import com.orderservice.demo.dto.OrderCreatedEvent;
import com.orderservice.demo.feign.ProductClient;
import com.orderservice.demo.model.Order;
import com.orderservice.demo.publisher.OrderEventPublisher;
import com.orderservice.demo.repository.OrderRepository;

import io.github.resilience4j.circuitbreaker.annotation.CircuitBreaker;

import java.util.List;

@Service
public class OrderService {

    private final OrderRepository repository;
    private final ProductClient productClient;
    private final OrderEventPublisher publisher;

    public OrderService(OrderRepository repository,
                        ProductClient productClient,
                        OrderEventPublisher publisher) {
        this.repository = repository;
        this.productClient = productClient;
        this.publisher = publisher;
    }

    @CircuitBreaker(name = "productService", fallbackMethod = "productFallback")
    public Order save(Order order) {

        // Call Product Service
        ProductResponseDTO product = productClient.getProductById(order.getProductId());

        // Calculate total price
        Double total = product.getPrice() * order.getQuantity();
        order.setTotalAmount(total);

        // Save order in DB
        Order savedOrder = repository.save(order);

        // Create event for messaging
        OrderCreatedEvent event = new OrderCreatedEvent(
                savedOrder.getId(),
                savedOrder.getProductId(),
                savedOrder.getQuantity(),
                savedOrder.getTotalAmount()
        );

        // Publish event to RabbitMQ
        System.out.println("Publishing Order Event: " + event);
        publisher.publishOrderEvent(event);

        return savedOrder;
    }

    // Circuit Breaker fallback
    public Order productFallback(Order order, Throwable t) {

        System.out.println("Product service is down. Error: " + t.getMessage());

        Order dummyOrder = new Order();
        dummyOrder.setProductId(order.getProductId());
        dummyOrder.setQuantity(order.getQuantity());
        dummyOrder.setTotalAmount(0.0);

        return dummyOrder;
    }

    public List<Order> getAll() {
        return repository.findAll();
    }
}