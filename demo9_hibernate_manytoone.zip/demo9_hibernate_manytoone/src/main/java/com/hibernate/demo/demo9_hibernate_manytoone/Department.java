package com.hibernate.demo.demo9_hibernate_manytoone;

import java.util.List;

import jakarta.persistence.*;

@Entity
@Table(name = "department")
public class Department {

	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private Long id;

	@Column(name = "name")
	private String name;
	@OneToMany(mappedBy = "department")
	private List<Student>student;
	// Default constructor
	public Department() {
	}

	// Parameterized constructor
	public Department(String name) {
		this.name = name;
	}

	// Getters and setters
	public Long getId() {
		return id;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public List<Student> getStudent() {
		return student;
	}

	public void setStudent(List<Student> student) {
		this.student = student;
	}
	

}
