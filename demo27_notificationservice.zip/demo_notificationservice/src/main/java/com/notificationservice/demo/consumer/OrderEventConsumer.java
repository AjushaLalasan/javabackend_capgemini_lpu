package com.notificationservice.demo.consumer;

import org.springframework.amqp.rabbit.annotation.RabbitListener;
import org.springframework.stereotype.Service;

import com.notificationservice.demo.dto.OrderCreatedEvent;

@Service
public class OrderEventConsumer {

    @RabbitListener(queues = "notification-queue")
    public void consumeOrderEvent(OrderCreatedEvent event) {

        System.out.println("Received Order Event");

        System.out.println("Order ID: " + event.getOrderId());
        System.out.println("Product ID: " + event.getProductId());
        System.out.println("Quantity: " + event.getQuantity());
        System.out.println("Total Amount: " + event.getTotalAmount());

        System.out.println("Sending Email Notification...");
    }
}