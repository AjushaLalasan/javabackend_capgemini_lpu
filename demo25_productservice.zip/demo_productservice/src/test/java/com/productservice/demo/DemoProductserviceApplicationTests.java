package com.productservice.demo;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class DemoProductserviceApplicationTests {

	@Test
	void contextLoads() {
	}

}
