package com.springmvc.demo.repository;

import java.util.ArrayList;
import java.util.List;

import org.springframework.stereotype.Repository;

import com.springmvc.demo.model.Product;

@Repository
public class ProductDAO {
	public List<Product> getAllProducts() {

		List<Product> productList = new ArrayList<>();

		productList.add(new Product(1, "Laptop", 55000));
		productList.add(new Product(2, "Mobile", 25000));
		productList.add(new Product(3, "Headphones", 3000));

		return productList;

	}
}
