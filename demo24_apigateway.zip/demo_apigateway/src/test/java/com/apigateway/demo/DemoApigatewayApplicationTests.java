package com.apigateway.demo;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class DemoApigatewayApplicationTests {

	@Test
	void contextLoads() {
	}

}
