package com.orderservice.demo.config;

import org.springframework.amqp.core.TopicExchange;
import org.springframework.amqp.rabbit.connection.ConnectionFactory;
import org.springframework.amqp.rabbit.core.RabbitTemplate;
import org.springframework.amqp.support.converter.Jackson2JsonMessageConverter;
import org.springframework.amqp.support.converter.MessageConverter;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

@Configuration
public class RabbitMQConfig {

    public static final String EXCHANGE = "order-exchange";
    public static final String ROUTING_KEY = "order.created";

    @Bean
    public TopicExchange orderExchange() {
        return new TopicExchange(EXCHANGE);
    }

    @Bean
    public MessageConverter messageConverter() {
        return new Jackson2JsonMessageConverter();
    }

    @Bean
    public RabbitTemplate rabbitTemplate(ConnectionFactory connectionFactory) {

        RabbitTemplate rabbitTemplate = new RabbitTemplate(connectionFactory);
        rabbitTemplate.setMessageConverter(messageConverter());

        // Required for returned message
        rabbitTemplate.setMandatory(true);

        rabbitTemplate.setReturnsCallback(returned ->
                System.out.println(
                        "Returned Message: "
                                + new String(returned.getMessage().getBody())
                                + " | Exchange: " + returned.getExchange()
                                + " | RoutingKey: " + returned.getRoutingKey()
                                + " | Reason: " + returned.getReplyText()
                ));

        rabbitTemplate.setConfirmCallback((correlationData, ack, cause) -> {
            if (ack) {
                System.out.println("Message successfully delivered to exchange");
            } else {
                System.out.println("Message delivery failed: " + cause);
            }
        });

        return rabbitTemplate;
    }
}