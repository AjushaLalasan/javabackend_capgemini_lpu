package com.notificationservice.demo;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class DemoNotificationserviceApplicationTests {

	@Test
	void contextLoads() {
	}

}
