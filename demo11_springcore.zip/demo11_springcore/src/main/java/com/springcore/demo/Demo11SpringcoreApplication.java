package com.springcore.demo;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.context.ApplicationContext;
import org.springframework.context.ConfigurableApplicationContext;

@SpringBootApplication
public class Demo11SpringcoreApplication {

	public static void main(String[] args) {
		ApplicationContext context = SpringApplication.run(Demo11SpringcoreApplication.class, args);
		Car car1 = context.getBean(Car.class);
		Car car2 = context.getBean(Car.class);
		car1.drive();
		System.out.println(car1);
		System.out.println(car2);
	}
	

}
