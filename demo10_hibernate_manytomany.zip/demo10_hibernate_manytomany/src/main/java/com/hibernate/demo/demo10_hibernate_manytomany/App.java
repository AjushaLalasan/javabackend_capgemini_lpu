package com.hibernate.demo.demo10_hibernate_manytomany;

import jakarta.persistence.*;
import java.util.HashSet;
import java.util.Set;

public class App {

    public static void main(String[] args) {

        EntityManagerFactory emf =
                Persistence.createEntityManagerFactory("myPersistenceUnit");

        EntityManager em = emf.createEntityManager();
        EntityTransaction tx = em.getTransaction();

        tx.begin();

        // Create Projects
        Project p1 = new Project("Banking System");
        Project p2 = new Project("Insurance System");

        // Create project set
        Set<Project> projectSet = new HashSet<>();
        projectSet.add(p1);
        projectSet.add(p2);

        // Create Employees
        Employee emp1 = new Employee("John", projectSet);
        Employee emp2 = new Employee("Sara", projectSet);

        
        // Create employee set
        Set<Employee> employeeSet = new HashSet<>();
        employeeSet.add(emp1);
        employeeSet.add(emp2);

        // Set employees in project (bidirectional)
        p1.setEmployees(employeeSet);
        p2.setEmployees(employeeSet);

        // Persist only employees (cascade will save projects)
        em.persist(emp1);
        em.persist(emp2);

        tx.commit();

        em.close();
        emf.close();

        System.out.println("Data saved successfully");
    }
}
