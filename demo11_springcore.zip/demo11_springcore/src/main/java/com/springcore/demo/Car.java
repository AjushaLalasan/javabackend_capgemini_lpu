package com.springcore.demo;

import org.springframework.context.annotation.Scope;
import org.springframework.stereotype.Component;

import jakarta.annotation.PostConstruct;
import jakarta.annotation.PreDestroy;

@Component
//@Scope("prototype")
public class Car {
	
	public Car() {
		System.out.println("Car bean created by Spring");
	}
	
	public void drive() {
		System.err.println("Driving car...");
	}
	@PostConstruct
	public void init() {
		System.out.println("Car bean initialed");
	}
	@PreDestroy
	public void destroy() {
		System.out.println("Car bean destroyed");
	}
}
