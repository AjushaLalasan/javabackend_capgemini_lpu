package com.springmvc.demo;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class Demo15SpringmvcApplicationTests {

	@Test
	void contextLoads() {
	}

}
