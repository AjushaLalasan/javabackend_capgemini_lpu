package com.notificationservice.demo.dto;

public class OrderCreatedEvent {

	private Long orderId;
	private Long productId;
	private Integer quantity;
	private Double totalAmount;

	public OrderCreatedEvent() {
	}

	public OrderCreatedEvent(Long orderId, Long productId, Integer quantity, Double totalAmount) {
		super();
		this.orderId = orderId;
		this.productId = productId;
		this.quantity = quantity;
		this.totalAmount = totalAmount;
	}

	public Long getOrderId() {
		return orderId;
	}

	public Long getProductId() {
		return productId;
	}

	public Integer getQuantity() {
		return quantity;
	}

	public Double getTotalAmount() {
		return totalAmount;
	}

	public void setOrderId(Long orderId) {
		this.orderId = orderId;
	}

	public void setProductId(Long productId) {
		this.productId = productId;
	}

	public void setQuantity(Integer quantity) {
		this.quantity = quantity;
	}

	public void setTotalAmount(Double totalAmount) {
		this.totalAmount = totalAmount;
	}
}