package com.hibernate.demo.demo9_hibernate_manytoone;


import jakarta.persistence.*;

@Entity
@Table(name = "student")
public class Student {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @Column(name = "name")
    private String name;

    @ManyToOne(fetch =FetchType.EAGER)
    @JoinColumn(name = "department_id") // Foreign key column
    private Department department;

    // Default constructor
    public Student() {}

    // Parameterized constructor
    public Student(String name, Department department) {
        this.name = name;
        this.department = department;
    }

    // Getters and setters
    public Long getId() {
        return id;
    }

    public String getName() {
        return name;
    }

    public Department getDepartment() {
        return department;
    }

    public void setName(String name) {
        this.name = name;
    }

    public void setDepartment(Department department) {
        this.department = department;
    }

}
