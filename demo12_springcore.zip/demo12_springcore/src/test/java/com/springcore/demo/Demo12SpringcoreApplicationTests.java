package com.springcore.demo;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class Demo12SpringcoreApplicationTests {

	@Test
	void contextLoads() {
	}

}
