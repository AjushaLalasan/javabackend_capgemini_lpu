package com.notificationservice.demo.consumer;

import org.springframework.amqp.rabbit.annotation.RabbitListener;
import org.springframework.stereotype.Service;

import com.notificationservice.demo.config.RabbitMQConfig;
import com.notificationservice.demo.dto.OrderCreatedEvent;

@Service
public class OrderEventConsumer {

    @RabbitListener(queues = RabbitMQConfig.QUEUE)
    public void consumeOrderEvent(OrderCreatedEvent event) {

        System.out.println("====================================");
        System.out.println("Received Order Event");

        System.out.println("Order ID: " + event.getOrderId());
        System.out.println("Product ID: " + event.getProductId());
        System.out.println("Quantity: " + event.getQuantity());
        System.out.println("Total Amount: " + event.getTotalAmount());

        // Simulate failure for retry
        if (event.getQuantity() > 2) {
            System.out.println("Simulating failure... message will retry");
            throw new RuntimeException("Processing failed");
        }
        System.out.println("Sending Email Notification...");
        System.out.println("Notification sent successfully");
    }
}