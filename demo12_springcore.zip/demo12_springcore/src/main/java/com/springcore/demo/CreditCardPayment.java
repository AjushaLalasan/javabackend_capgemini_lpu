package com.springcore.demo;

import org.springframework.stereotype.Component;

@Component
public class CreditCardPayment implements Payment{

	public void pay() {
		System.out.println("Paid using credit card");
	}

}
