package com.springmvc.demo;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class Demo16SpringmvcApplication {

	public static void main(String[] args) {
		SpringApplication.run(Demo16SpringmvcApplication.class, args);
	}

}
