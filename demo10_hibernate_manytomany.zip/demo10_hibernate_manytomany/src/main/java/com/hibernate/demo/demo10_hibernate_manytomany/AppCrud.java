package com.hibernate.demo.demo10_hibernate_manytomany;

import jakarta.persistence.*;
import java.util.HashSet;
import java.util.Set;

public class AppCrud {

	public static void main(String[] args) {

		EntityManagerFactory emf = Persistence.createEntityManagerFactory("myPersistenceUnit");

		EntityManager em = emf.createEntityManager();

		// CREATE
		createData(em);

		// READ
		readEmployee(em, 1);

		// UPDATE
		updateEmployee(em, 1);

		// DELETE
		deleteEmployee(em, 2);

		em.close();
		emf.close();
	}

	// CREATE
	public static void createData(EntityManager em) {

		EntityTransaction tx = em.getTransaction();
		tx.begin();

		Project p1 = new Project("Banking System");
		Project p2 = new Project("Insurance System");

		Set<Project> projectSet = new HashSet<>();
		projectSet.add(p1);
		projectSet.add(p2);

		Employee emp1 = new Employee("John", projectSet);
		Employee emp2 = new Employee("Sara", projectSet);

		Set<Employee> employeeSet = new HashSet<>();
		employeeSet.add(emp1);
		employeeSet.add(emp2);

		p1.setEmployees(employeeSet);
		p2.setEmployees(employeeSet);

		em.persist(emp1);
		em.persist(emp2);

		tx.commit();

		System.out.println("CREATE SUCCESS");
	}

	// READ
	public static void readEmployee(EntityManager em, int id) {

		Employee emp = em.find(Employee.class, id);

		if (emp != null) {
			System.out.println("Employee ID: " + emp.getId());
			System.out.println("Employee Name: " + emp.getName());

			for (Project p : emp.getProjects()) {
				System.out.println("Project: " + p.getProjectName());
			}
		} else {
			System.out.println("Employee not found");
		}
	}

	// UPDATE
	public static void updateEmployee(EntityManager em, int id) {

		EntityTransaction tx = em.getTransaction();
		tx.begin();

		Employee emp = em.find(Employee.class, id);

		if (emp != null) {
			emp.setName("John Updated");
			em.merge(emp);
			System.out.println("UPDATE SUCCESS");
		}

		tx.commit();
	}

	// DELETE
	public static void deleteEmployee(EntityManager em, int id) {

		EntityTransaction tx = em.getTransaction();
		tx.begin();

		Employee emp = em.find(Employee.class, id);

		if (emp != null) {
			em.remove(emp);
			System.out.println("DELETE SUCCESS");
		}

		tx.commit();
	}
}
