package com.discoveryserver.demo;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.cloud.netflix.eureka.server.EnableEurekaServer;

@SpringBootApplication
@EnableEurekaServer
public class DemoDiscoveryserverApplication {

	public static void main(String[] args) {
		SpringApplication.run(DemoDiscoveryserverApplication.class, args);
	}

}
