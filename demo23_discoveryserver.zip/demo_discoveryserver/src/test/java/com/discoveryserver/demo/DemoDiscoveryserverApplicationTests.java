package com.discoveryserver.demo;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class DemoDiscoveryserverApplicationTests {

	@Test
	void contextLoads() {
	}

}
